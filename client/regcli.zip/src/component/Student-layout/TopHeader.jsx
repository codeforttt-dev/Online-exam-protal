const TopHeader = () => {
  return null;
};

export default TopHeader;
