// import API from "./axios";

// /* Save purchase */
// export const createPurchase = (data) =>
//   API.post("/purchases", data);

// /* Get my purchases */
// export const getMyPurchases = () =>
//   API.get("/purchases");
