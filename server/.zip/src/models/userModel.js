import mongoose from "mongoose";
import bcrypt from "bcryptjs";

/* ================= SIBLING ================= */
const siblingSchema = new mongoose.Schema({
  name: String,
  dob: Date,
  studentClass: String,
  school: String
});

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },

    username: {
      type: String,
      unique: true,
      sparse: true,
      trim: true,
      lowercase: true,
      index: true
    },

    email: {
      type: String,
      unique: true,
      sparse: true,
      index: true
    },

    password: String,

    mobile: {
      type: String,
      index: true
    },

    studentClass: String,

    whatsapp: {
      type: String,
      index: true
    },

    isPaid: { type: Boolean, default: false },
    profileCompleted: { type: Boolean, default: false },

    dob: Date,

    state: String,
    district: String,
    address: String,

    school: String,

    fatherName: String,
    motherName: String,

    siblings: [siblingSchema],

    role: {
      type: String,
      enum: ["student", "admin"],
      default: "student"
    },

    resetToken: String,
    resetTokenExpire: Date
  },
  { timestamps: true }
);

/* ================= HOOKS ================= */

// ✅ safe hashing only if password exists
userSchema.pre("save", async function () {
  if (!this.password || !this.isModified("password")) return;

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

userSchema.methods.matchPassword = async function (entered) {
  if (!this.password) return false;
  return bcrypt.compare(entered, this.password);
};

export default mongoose.model("User", userSchema);
